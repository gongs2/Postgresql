#!/bin/bash
# -----------------------------------------------------------------------------
# File: run_playbook.sh
# Project: PostgreSQL Automation Suite
# Maintainer: SSC Postgres Team
# Purpose: Interactive wrapper for running Ansible playbooks from the command line.
#
# Features:
# - Lists available playbook categories (subdirectories under playbooks/)
# - Prompts the user to select a category
# - Lists available playbooks in the selected category
# - Prompts for optional tags to filter tasks
# - Runs the selected playbook with predefined options for testing
#
# Usage:
# ./run_playbook.sh
# -----------------------------------------------------------------------------

PLAYBOOK_DIR="$PWD/playbooks"
VARS_FILE="$PWD/variables/external.yml"
clear -x

# -----------------------------------------------------------------------------
# Check if playbooks directory exists
# -----------------------------------------------------------------------------
if [ ! -d "$PLAYBOOK_DIR" ]; then
    echo "[ERROR]: Playbooks directory '$PLAYBOOK_DIR' not found."
    exit 1
fi

# -----------------------------------------------------------------------------
# List playbook subdirectories
# -----------------------------------------------------------------------------
mapfile -t subdirs < <(find "$PLAYBOOK_DIR" -mindepth 1 -maxdepth 1 -type d -exec basename {} \; | sort)

if [ ${#subdirs[@]} -eq 0 ]; then
    echo "No subdirectories found in '$PLAYBOOK_DIR'."
    exit 1
fi

echo -e "\nSelect a category:\n"

for i in "${!subdirs[@]}"; do
    printf "    %2d) %s\n" $((i + 1)) "${subdirs[i]}"
done

# -----------------------------------------------------------------------------
# Prompt for category
# -----------------------------------------------------------------------------
while true; do
    echo -ne "\n> "
    read -r category_choice

    if [[ "$category_choice" =~ ^[1-9][0-9]*$ ]] && ((category_choice > 0 && category_choice <= ${#subdirs[@]})); then
        subdir="${subdirs[category_choice-1]}"
        break
    else
        echo -e "\nInvalid selection. Try again.\n"
    fi
done

# -----------------------------------------------------------------------------
# List playbooks in selected subdirectory
# -----------------------------------------------------------------------------
mapfile -t playbooks < <(find "$PLAYBOOK_DIR/$subdir" -maxdepth 1 -name "*.yml" -exec basename {} .yml \; | sort)

if [ ${#playbooks[@]} -eq 0 ]; then
    echo "No playbooks found in '$PLAYBOOK_DIR/$subdir'."
    exit 1
fi

COLUMNS=1

echo -e "\nSelect a playbook from '$subdir' menu:\n"

for i in "${!playbooks[@]}"; do
    printf "    %2d) %s\n" $((i + 1)) "${playbooks[i]}"
done

# -----------------------------------------------------------------------------
# Prompt for playbook
# -----------------------------------------------------------------------------
while true; do
    echo -ne "\n> "
    read -r playbook_choice

    if [[ "$playbook_choice" =~ ^[1-9][0-9]*$ ]] && ((playbook_choice > 0 && playbook_choice <= ${#playbooks[@]})); then
        playbook="${playbooks[playbook_choice-1]}"
        break
    else
        echo -e "\nInvalid selection. Try again.\n"
    fi
done

# -----------------------------------------------------------------------------
# Prompt for tags (optional)
# -----------------------------------------------------------------------------
echo -e "\nEnter tags (separate multiple tags by commas, or press Enter to skip):"
read -r -p "> " tags_input

# -----------------------------------------------------------------------------
# Validate tags before running the playbook
# -----------------------------------------------------------------------------
TAGS_OPTION=""
if [[ -n "$tags_input" ]]; then
    echo -e "\nValidating tags...\n"

    # Get available tags from the playbook
    available_tags=$(ansible-playbook -i localhost, "$PLAYBOOK_DIR/$subdir/$playbook.yml" --list-tags | awk '/TASK TAGS:/ {getline; print}' | tr -d '[],')

    if [[ -z "$available_tags" ]]; then
        echo "[ERROR]: No tags found in playbook. Cannot validate tags."
        exit 1
    fi

    # Convert available tags to an array
    IFS=', ' read -r -a tag_array <<< "$available_tags"

    # Convert input tags into an array
    IFS=',' read -r -a input_tags <<< "$tags_input"

    # Validate each input tag
    for input_tag in "${input_tags[@]}"; do
        if [[ ! " ${tag_array[*]} " =~ (^|[[:space:]])${input_tag}([[:space:]]|$) ]]; then
            echo -e "[ERROR]: Tag '$input_tag' not found in the playbook '$playbook.yml'.\n"
            exit 1
        fi
    done

    TAGS_OPTION="--tags $tags_input"
fi

# -----------------------------------------------------------------------------
# Execute the selected playbook
# -----------------------------------------------------------------------------
echo -e "\nRunning: ansible-playbook -i localhost, -c local $PLAYBOOK_DIR/$subdir/$playbook.yml -e @$VARS_FILE $TAGS_OPTION\n"
ansible-playbook -i localhost, -c local "$PLAYBOOK_DIR/$subdir/$playbook.yml" -e @$VARS_FILE $TAGS_OPTION
