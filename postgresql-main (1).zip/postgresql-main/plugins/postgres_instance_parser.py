def parse_postgres_instance_data(results):
    parsed = []
    for r in results:
        if r.get("stdout"):
            parts = r["stdout"].split()
            if len(parts) == 4:
                parsed.append({
                    "name": parts[0],
                    "port": parts[1],
                    "data_dir": parts[2],
                    "log_dir": parts[3]
                })
    return parsed

class FilterModule(object):
    def filters(self):
        return {
            'parse_postgres_instance_data': parse_postgres_instance_data
        }
