#!/bin/bash
# -----------------------------------------------------------------------------
# File: pg_status.sh
# Project: PostgreSQL Automation Suite
# Maintainer: SSC Postgres Team
# Purpose: Check the running status of a PostgreSQL instance.
#
# Features:
# - Validates the instance name and service file existence.
# - Dynamically determines the service name for the PostgreSQL instance.
# - Uses pg_isready to check if the instance is accepting connections.
# - Displays the service status.
# -----------------------------------------------------------------------------

# ------------------------------------------------------------
# Check if the argument is provided
# ------------------------------------------------------------
if [ -z "$1" ]; then
  echo "Usage: $0 <instance_name>"
  exit 1
fi

# ------------------------------------------------------------
# Set relevant variables
# ------------------------------------------------------------
INSTANCE_NAME="$1"
SERVICE_NAME="postgresql-$INSTANCE_NAME"
SERVICE_FILE="/etc/systemd/system/$SERVICE_NAME.service"
PG_BIN_PATH="/usr/pgsql-16/bin/pg_isready"
PGPORT=$(grep ExecStart "$SERVICE_FILE" | awk -F'-p ' '{print $2}' | awk '{print $1}')

# ------------------------------------------------------------
# Validate the service file existence
# ------------------------------------------------------------
if [ ! -f "$SERVICE_FILE" ]; then
  echo "Error: Service file $SERVICE_FILE not found."
  exit 1
fi

# ------------------------------------------------------------
# Check if the service is running
# ------------------------------------------------------------
STATUS=$(systemctl is-active "$SERVICE_NAME")
if [ "$STATUS" != "active" ]; then
  echo -e "PostgreSQL service for instance $INSTANCE_NAME is not running.\n"
fi

# ------------------------------------------------------------
# Check database readiness using pg_isready
# ------------------------------------------------------------
echo -e "Connectivity status for instance $INSTANCE_NAME:\n"
$PG_BIN_PATH -p $PGPORT
echo

# ------------------------------------------------------------
# Display the service status
# ------------------------------------------------------------
echo -e "Service status for instance $INSTANCE_NAME:\n"
systemctl status "$SERVICE_NAME"
