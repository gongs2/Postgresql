# PostgreSQL Automation Suite

## Last Update

README Last Updated: `2025-03-20 17:00:51`

## Maintainers
- Mario Dionne (Mario.Dionne@ssc-spc.gc.ca)
- Zoran Kulina (Zoran.Kulina@ssc-spc.gc.ca)

## Description

This repository contains Ansible playbooks for managing PostgreSQL on Red Hat Enterprise Linux platform. These playbooks automate:
- Installation
- Configuration
- Maintenance
- Security
- Monitoring
- High Availability

## Prerequisites
- RHEL 9 or CentOS 9 installed
- Ansible (full package, not `ansible-core`)
- Full sudo access for automation user (`ansible`)
- Internally hosted PostgreSQL package repository with the following components:
    - PostgreSQL server
    - PostgreSQL contrib
    - PostgreSQL libs
    - pgaudit
    - libssh2
    - python3-psycopg2
    - pgBackRest

## Disk Requirements

### PostgreSQL Mount Points General Guidelines

- Mount points should be structured to optimize performance and facilitate manageability (e.g., separation of different type of data and metadata).
- Ensure adequate disk provisioning based on workload type (OLTP vs. OLAP), database size and expected growth.
- Use separate mount points to prevent I/O contention between different PostgreSQL components.
- Consider using dedicated storage devices (e.g., SSDs) for high-activity workloads.
- Implement appropriate file system options (e.g., noatime, nodiratime, realtime) to optimize performance.

### Disk Space Recommendations

| Mount Point       | Recommended Size                                           | Purpose                                  | Comments / Best Practices |
|-------------------|----------------------------------------------------------|------------------------------------------|---------------------------|
| /usr/pgsql        | Single version: 5 - 10 GB  <br> Multiple versions: 10 - 15 GB | PostgreSQL binaries                     | Avoid mounting `/usr/pgsql/` separately to prevent breaking `dnf`. Install PostgreSQL under the default mount point and ensure adequate space. <br><br> *(This is the default install location, no need to create a separate mount point – just allocate enough space.)* |
| /pgdata           | Determined by client needs                               | PostgreSQL data directory               | Use a single `/pgdata` mount for most use cases. Consider multiple data directories (`/pgdata1`, `/pgdata2`, etc.) only for special OLAP cases. <br><br> PostgreSQL does not support automatic striping, so multiple mount points do not provide the same benefits as in Oracle or DB2. <br><br> **Recommendation:** <br> - Use a single `/pgdata` mount for general workloads. <br> - If specific databases are highly I/O-intensive, use separate tablespaces on different mount points. <br> - Prefer SAN striping over multiple mount points. <br> - HA setups like Patroni assume a single `/pgdata` mount. |
| /pgwal            | Low activity: 5 - 10 GB <br> Moderate activity: 10 - 50 GB <br> High activity: 50 - 100 GB | Write-Ahead Log (WAL) storage           | Implemented using `--waldir=<postgres_wal_dir>` option, which creates a symbolic link, e.g.: <br><br> ```bash [root@server inst1]# ls -l pg_wal lrwxrwxrwx. 1 postgres postgres 12 Feb 18 14:39 pg_wal -> /pgwal/inst1 ``` <br><br> **Considerations:** <br> - Ensure the target directory is always available (use systemd dependencies). <br> - Be cautious with backups (ensure WAL is copied correctly). <br> - Secure symlink ownership and permissions. |
| /pgtemp           | Low activity (small DB, OLTP-focused): 10 - 20 GB <br> Moderate activity (medium DB, OLTP & OLAP mix): 20 - 50 GB <br> High activity (large DB, OLAP-heavy): 50 - 200 GB | Temporary files for sorts, hash joins, and temp tables | Use a **high-speed volume** to improve query performance, especially for OLAP workloads. |
| /pglog            | Typically 2 - 5 GB                                       | PostgreSQL diagnostic logs               | Log rotation will be configured to prevent large files. |
| /pgbackup         | Determined by client needs (based on database size, backup frequency, and retention requirements) | PostgreSQL database backups and WAL archives             | *Ideally, this file system won't be needed in the long run if Commvault File System-Based Backups (FSBasedBackupSet) are used to directly backup data files.* |

**Note:** In the lab environment, we will **not** mount file systems but will instead create them as directories. However, in **customer-facing environments**, these mount points should be configured as separate file systems to ensure better isolation, performance and manageability.


## Network Requirements
- SSH access must be enabled to the target host(s).
- Network flows must be open between the Ansible control node and the target host(s):

| Component                    | Port      | Direction                            | Purpose                                               |
|------------------------------|-----------|--------------------------------------|-------------------------------------------------------|
| SSH                          | 22        | Ansible → Target host                | Ansible communication                                 |
| PostgreSQL                   | 5431-5439 | Primary → Replica, App → DB          | Database connections and WAL streaming replication    |
| Patroni REST API             | 8008      | Bi-directional between Patroni nodes | Cluster state updates, leader election, health checks |
| etcd Client API Port         | 2379      | Patroni nodes → etcd cluster         | Configuration store and leader election               |
| etcd Peer Communication Port | 2380      | Between etcd cluster nodes           | etcd cluster communication                            |

## Lab Environment Setup

### 1. Install CentOS 9 or RHEL 9

Follow the standard installation procedures.

### 2. Register RHEL 9 with Red Hat Subscription Manager (Skip for CentOS)

```bash
sudo subscription-manager register --force
sudo subscription-manager attach --auto
sudo subscription-manager refresh
```

### 3. Install Ansible

```bash
sudo dnf install -y epel-release
sudo dnf install -y ansible
```
**Notes:**
- Skip this step in customer-facing environments where EPEL is not supported, as playbooks will be executed through Ansible Automation Platform (AAP) using job templates.
- Install the full Ansible package (ansible), not just ansible-core, as ansible-core lacks essential modules and plugins required by this repository.


### 4. Create the Ansible user and configure access (Run as `root`)

```bash
# Create the 'ansible' user
useradd -m -s /bin/bash ansible

# Enable passwordless sudo for 'ansible'
echo "ansible ALL=(ALL) NOPASSWD:ALL" | tee /etc/sudoers.d/ansible

# Disable password login for 'ansible' in SSH
echo -e "Match User ansible\n\tPasswordAuthentication no\n\tPubkeyAuthentication yes" | tee -a /etc/ssh/sshd_config

# Restart SSH service
systemctl restart sshd

# Verify sudoers entry
cat /etc/sudoers.d/ansible

# Check sudo access
su - ansible -c "sudo whoami"  # Should return 'root'
```

### 5. Add the public key from `secrets\ansible.pub` to `~\.ssh\authorized_keys` (Run as `ansible`)

```bash
mkdir -p ~/.ssh
touch ~/.ssh/authorized_keys
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys
cat ansible.pub >> ~/.ssh/authorized_keys
```
**Note:** Skip this step when running in a lab environment where commands are executed from the command line.

## Usage

### Running a Playbook

1. Inspect the playbook to determine required variables.
2. Define the required variables in `variables/external.yml`.
3. Execute `run_playbook.sh`.
4. Select the desired playbook from the menu.
5. Specify tags if needed (optional).

### Example: Installing PostgreSQL

#### 1. Determine Required Variables

Inspect `required_vars` in `playbooks/postgres_install.yml`:

```yaml
- name: Install PostgreSQL
  hosts: all
  become: yes
  gather_facts: yes
  vars_files:
    - "<repository>/variables/main.yml"
  roles:
    - role: check_variables
      vars:
        required_vars:
          - postgres_version   # <--------- Required Variable

  tasks:

    # -----------------------------------------------------------------------------
    # Install PostgreSQL and prerequisites
    # -----------------------------------------------------------------------------
    - name: Start PostgreSQL installation tasks
      import_tasks:  "<repository>/tasks/install.yml"
```

#### 2. Define Required Variables in `variables/external.yml`

```yaml
# -----------------------------------------------------------------------------
# File: external.yml
# Project: PostgreSQL Automation Suite
# Maintainer: SSC Postgres Team
# Purpose: External variables to be defined at runtime.
# -----------------------------------------------------------------------------

postgres_version: "16"           # PostgreSQL major version (e.g., 15, 16, ...)

```

#### 3. Run the Wrapper Script

```bash
$ run_playbook.sh

Select a category:

     1) access_management
     2) database_operations
     3) high_availability
     4) installation
     5) maintenance
     6) monitoring
     7) security_checks
     8) utilities

> 4

Select a playbook from 'installation' menu:

     1) postgres_full_setup
     2) postgres_full_teardown
     3) postgres_install
     4) postgres_instance_configure
     5) postgres_instance_create
     6) postgres_instance_delete
     7) postgres_uninstall

> 3

Enter tags (separate multiple tags by commas, or press Enter to skip):
>
```
#### Sample Execution Output:

```text
Running: ansible-playbook -i localhost, -c local /home/ansible/postgresql/playbooks/installation/postgres_install.yml -e @/home/ansible/postgresql/variables/external.yml

PLAY [Install PostgreSQL] ****************************************************************************************

TASK [Gathering Facts] *******************************************************************************************
ok: [localhost]

TASK [check_variables : Ensure required_vars is defined] *********************************************************
skipping: [localhost]

TASK [check_variables : Print required_vars] *********************************************************************
ok: [localhost] => (item=postgres_version) =>
  msg: postgres_version = 16
ok: [localhost] => (item=postgres_repo_url) =>
  msg: postgres_repo_url = http://***.***.***.***/ansible/postgres-repository/-/raw/main/pgdg16

TASK [check_variables : Check whether required playbook variables are set] ***************************************
skipping: [localhost] => (item=postgres_version)
skipping: [localhost] => (item=postgres_repo_url)
skipping: [localhost]

TASK [Gather installed package facts] ****************************************************************************
ok: [localhost]

TASK [Set PostgreSQL package name] *******************************************************************************
ok: [localhost]

TASK [Abort if PostgreSQL 16 is already installed] ***************************************************************
skipping: [localhost]

TASK [Remove existing PostgreSQL repository] *********************************************************************
ok: [localhost]

TASK [Clean DNF cache for pgdg repository] ***********************************************************************
skipping: [localhost]

TASK [Regenerate DNF cache for pgdg repository] ******************************************************************
skipping: [localhost]

TASK [Configure PostgreSQL repository for package installation] **************************************************
changed: [localhost]

TASK [Ensure PostgreSQL repository is enabled] *******************************************************************
changed: [localhost]

TASK [Disable the built-in PostgreSQL module] ********************************************************************
ok: [localhost]

TASK [Install PostgreSQL packages from repository] ***************************************************************
changed: [localhost]

TASK [Configure pgBackRest] **************************************************************************************
changed: [localhost]

TASK [Get postgres user's home directory] ************************************************************************
changed: [localhost]

TASK [Parse postgres user's home directory] **********************************************************************
ok: [localhost]

TASK [Copy DBA shell scripts to postgres user's home directory] **************************************************
ok: [localhost]

TASK [Remove PGDATA from postgres user's .bash_profile] **********************************************************
changed: [localhost]

TASK [Add PostgreSQL binary path to postgres user's .bash_profile] ***********************************************
changed: [localhost]

TASK [Create sudoers file for postgres user] *********************************************************************
ok: [localhost]

TASK [Check installed PostgreSQL packages] ***********************************************************************
ok: [localhost]

TASK [Filter installed PostgreSQL packages] **********************************************************************
ok: [localhost]

TASK [Display installed PostgreSQL packages] *********************************************************************
Pausing for 1 seconds
(ctrl+C then 'C' = continue early, ctrl+C then 'A' = abort)
[Display installed PostgreSQL packages]

Installed PostgreSQL packages:

postgresql16-contrib.x86_64                      16.6-1PGDG.rhel9                 @pdgd
postgresql16-libs.x86_64                         16.6-1PGDG.rhel9                 @pdgd
postgresql16-server.x86_64                       16.6-1PGDG.rhel9                 @pdgd
postgresql16.x86_64                              16.6-1PGDG.rhel9                 @pdgd

:
ok: [localhost]

TASK [Check installed PostgreSQL version] ************************************************************************
ok: [localhost]

TASK [Display installed PostgreSQL version] **********************************************************************
ok: [localhost] =>
  msg: |2-

    INFO: PostgreSQL version installed: psql (PostgreSQL) 16.6

PLAY RECAP *******************************************************************************************************
localhost                  : ok=21   changed=7    unreachable=0    failed=0    skipped=5    rescued=0    ignored=0

Playbook run took 0 days, 0 hours, 0 minutes, 18 seconds
```

## Directory Structure

For more details, refer to the specific playbooks inside each directory.

```bash
/home/ansible/postgresql/playbooks/utilities/../..
├── collections
│   └── ansible_collections
│       ├── community
│       │   └── postgresql
│       └── community.postgresql-3.10.0.info
│           └── GALAXY.yml
├── dba_scripts
│   ├── pg_env.sh
│   ├── pg_ilist.sh
│   ├── pg_start.sh
│   ├── pg_status.sh
│   └── pg_stop.sh
├── inventories
│   └── hosts.yml
├── playbooks
│   ├── access_management
│   │   ├── postgres_password_reset.yml
│   │   ├── postgres_privileges_manage.yml
│   │   ├── postgres_role_add_attributs.yml
│   │   ├── postgres_role_create.yml
│   │   ├── postgres_role_drop.yml
│   │   ├── postgres_role_grant.yml
│   │   ├── postgres_role_revoke.yml
│   │   ├── postgres_user_create.yml
│   │   └── postgres_user_drop.yml
│   ├── database_operations
│   │   ├── postgres_db_configure.yml
│   │   ├── postgres_db_create.yml
│   │   ├── postgres_db_drop.yml
│   │   └── postgres_db_extensions_manage.yml
│   ├── high_availability
│   │   ├── postgres_failover.yml
│   │   ├── postgres_primary_node_setup.yml
│   │   └── postgres_replica_node_setup.yml
│   ├── installation
│   │   ├── postgres_full_setup.yml
│   │   ├── postgres_full_teardown.yml
│   │   ├── postgres_install.yml
│   │   ├── postgres_instance_configure.yml
│   │   ├── postgres_instance_create.yml
│   │   ├── postgres_instance_delete.yml
│   │   └── postgres_uninstall.yml
│   ├── maintenance
│   │   ├── postgres_backup_info.yml
│   │   ├── postgres_backup_set_info.yml
│   │   ├── postgres_backup.yml
│   │   ├── postgres_extension_deactivate.yml
│   │   ├── postgres_extension_upgrade.yml
│   │   ├── postgres_info.yml
│   │   ├── postgres_list_backups.yml
│   │   ├── postgres_logs_purge.yml
│   │   ├── postgres_major_upgrade.yml
│   │   ├── postgres_minor_update.yml
│   │   ├── postgres_restore_db_from_standby.yml
│   │   ├── postgres_restore_end_of_backup.yml
│   │   ├── postgres_restore_end_of_log.yml
│   │   ├── postgres_restore_latest_PIT.yml
│   │   ├── postgres_restore_LSN.yml
│   │   ├── postgres_restore_old.yml
│   │   ├── postgres_restore_PIT.yml
│   │   ├── postgres_restore.yml
│   │   ├── postgres_start_all.yml
│   │   ├── postgres_start.yml
│   │   ├── postgres_status_all.yml
│   │   ├── postgres_status.yml
│   │   ├── postgres_stop_all.yml
│   │   ├── postgres_stop.yml
│   │   └── postgres_vacuum_analyze.yml
│   ├── monitoring
│   │   ├── postgres_alerting.yml
│   │   ├── postgres_autovacuum_stats.yml
│   │   ├── postgres_connection_stats.yml
│   │   ├── postgres_disk_usage.yml
│   │   ├── postgres_health_check.yml
│   │   ├── postgres_memory_usage.yml
│   │   ├── postgres_query_performance.yml
│   │   └── postgres_replication_status.yml
│   ├── security_checks
│   │   ├── postgres_cis_benchmark_check.yml
│   │   ├── postgres_configuration_baseline_check.yml
│   │   ├── postgres_security_hardening_check.yml
│   │   └── postgres_user_privileges_check.yml
│   └── utilities
│       ├── readme.yml
│       ├── site.yml
│       └── test.yml
├── roles
│   ├── check_postgres_env
│   │   └── tasks
│   │       └── main.yml
│   ├── check_variables
│   │   └── tasks
│   │       └── main.yml
│   ├── gather_instance_facts
│   │   └── tasks
│   │       └── main.yml
│   ├── print_instance_facts
│   │   └── tasks
│   │       └── main.yml
│   ├── print_instance_list
│   │   └── tasks
│   │       └── main.yml
│   ├── print_instance_status
│   │   └── tasks
│   │       └── main.yml
│   └── promote_post_restore
│       └── tasks
│           └── main.yml
├── secrets
│   ├── ansible.pub
│   ├── secret_vars.yml
│   └── vault
├── tasks
│   ├── install.yml
│   ├── instance_config_check.yml
│   ├── instance_configure.yml
│   ├── instance_create.yml
│   ├── instance_delete.yml
│   ├── instance_start_all.yml
│   ├── instance_stop_all.yml
│   └── uninstall.yml
├── templates
│   ├── pgbackrest.conf.j2
│   ├── pgbackrest_logrotate.j2
│   ├── pg_hba.conf.j2
│   ├── postgresql.conf.j2
│   ├── postgresql.service.j2
│   ├── postgres_sudoers.j2
│   └── README.md.j2
├── variables
│   ├── external.yml
│   └── main.yml
├── ansible.cfg
├── README.md
└── run_playbook.sh

```
