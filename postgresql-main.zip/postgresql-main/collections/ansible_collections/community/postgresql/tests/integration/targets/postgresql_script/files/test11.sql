SELECT make_interval(secs => 3)
