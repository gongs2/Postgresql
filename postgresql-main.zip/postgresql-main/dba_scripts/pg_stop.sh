#!/bin/bash
# -----------------------------------------------------------------------------
# File: pg_stop.sh
# Project: PostgreSQL Automation Suite
# Author: Zoran Kulina
# Maintainer: SSC Postgres Team
# Purpose: Stops the PostgreSQL service for a specific instance.
#
# Features:
# - Validates the instance name and service file existence.
# - Dynamically determines the service name for the PostgreSQL instance.
# - Checks if the service is already stopped.
# - Stops the PostgreSQL service for the specified instance.
# - Displays the service status after attempting to stop it.
# -----------------------------------------------------------------------------

# ------------------------------------------------------------
# Check if the argument is provided
# ------------------------------------------------------------
if [ -z "$1" ]; then
  echo "Usage: $0 <instance_name>"
  exit 1
fi

INSTANCE_NAME="$1"

# ------------------------------------------------------------
# Determine the service name
# ------------------------------------------------------------
SERVICE_NAME="postgresql-$INSTANCE_NAME"
SERVICE_FILE="/etc/systemd/system/$SERVICE_NAME.service"
if [ ! -f "$SERVICE_FILE" ]; then
  echo "Error: Service file $SERVICE_FILE not found."
  exit 1
fi

# ------------------------------------------------------------
# Check if the service is already stopped
# ------------------------------------------------------------
STATUS=$(systemctl is-active "$SERVICE_NAME")
if [ "$STATUS" == "inactive" ]; then
  echo "PostgreSQL service for instance $INSTANCE_NAME is already stopped."
  exit 0
fi

# ------------------------------------------------------------
# Stop the PostgreSQL service
# ------------------------------------------------------------
echo "Stopping PostgreSQL service for instance: $INSTANCE_NAME"
sudo systemctl stop "$SERVICE_NAME"

# ------------------------------------------------------------
# Check the status of the service
# ------------------------------------------------------------
STATUS=$(systemctl is-active "$SERVICE_NAME")
if [ "$STATUS" == "inactive" ]; then
  echo "PostgreSQL service for instance $INSTANCE_NAME has been stopped."
else
  echo "Failed to stop PostgreSQL service for instance $INSTANCE_NAME."
  exit 1
fi

# ------------------------------------------------------------
# Display the service status
# ------------------------------------------------------------
echo "Service status for instance $INSTANCE_NAME:"
systemctl status "$SERVICE_NAME"

