#!/bin/bash
# -----------------------------------------------------------------------------
# File: pg_ilist.sh
# Project: PostgreSQL Automation Suite
# Author: Zoran Kulina
# Maintainer: SSC Postgres Team
# Purpose: List PostgreSQL instances. Similar to pg_lsclusters.
#
# Features:
# -----------------------------------------------------------------------------

BASE_DIR="/pgdata"
echo
echo -e "Instance\tPort\t\tVersion\t\tData Directory\tService Name\t\t Status"
echo -e "---------------\t---------------\t---------------\t---------------\t---------------\t---------------"

for DIR in "$BASE_DIR"/*; do
  if [ -d "$DIR" ] && [ -f "$DIR/postgresql.conf" ]; then
    INSTANCE=$(basename "$DIR")
    PORT=$(grep -E "^port\s*=" "$DIR/postgresql.conf" | awk '{print $3}')
    VERSION=$(cat "$DIR/PG_VERSION" 2>/dev/null || echo "unknown")
    SERVICE_NAME="postgresql-${INSTANCE}"
    STATUS=$(pgrep -u postgres -f "$DIR" > /dev/null && echo "Running" || echo "Stopped")
    echo -e "${INSTANCE}\t\t${PORT:-unknown}\t\t${VERSION}\t\t${DIR}\t${SERVICE_NAME}\t${STATUS}"
  fi
done
echo
