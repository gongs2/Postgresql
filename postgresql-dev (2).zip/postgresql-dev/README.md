# Ansible Playbooks for PostgreSQL Automation Suite

**Last Updated:** `2025-03-03 15:53:44`

**Maintainers:**
- Mario Dionne
- Zoran Kulina

**Description:**

This repository contains Ansible playbooks for managing **PostgreSQL on RHEL**. The playbooks automate **installation, configuration, maintenance, security, monitoring high availability and more**.


## Directory Structure

```bash
/home/ansible/postgresql/playbooks/utilities/../..
├── collections
│   └── ansible_collections
│       ├── community
│       │   └── postgresql
│       └── community.postgresql-3.10.0.info
│           └── GALAXY.yml
├── dba_scripts
│   ├── pg_env.sh
│   ├── pg_ilist.sh
│   ├── pg_start.sh
│   ├── pg_status.sh
│   └── pg_stop.sh
├── inventories
│   └── hosts.yml
├── playbooks
│   ├── access_management
│   │   ├── postgres_password_reset.yml
│   │   ├── postgres_privileges_manage.yml
│   │   ├── postgres_role_add_attributs.yml
│   │   ├── postgres_role_create.yml
│   │   ├── postgres_role_drop.yml
│   │   ├── postgres_role_grant.yml
│   │   ├── postgres_role_revoke.yml
│   │   ├── postgres_user_create.yml
│   │   └── postgres_user_drop.yml
│   ├── database_operations
│   │   ├── postgres_db_configure.yml
│   │   ├── postgres_db_create.yml
│   │   ├── postgres_db_drop.yml
│   │   └── postgres_db_extensions_manage.yml
│   ├── high_availability
│   │   ├── postgres_failover.yml
│   │   ├── postgres_primary_node_setup.yml
│   │   └── postgres_replica_node_setup.yml
│   ├── installation
│   │   ├── postgres_full_setup.yml
│   │   ├── postgres_full_teardown.yml
│   │   ├── postgres_install.yml
│   │   ├── postgres_instance_configure.yml
│   │   ├── postgres_instance_create.yml
│   │   ├── postgres_instance_delete.yml
│   │   └── postgres_uninstall.yml
│   ├── maintenance
│   │   ├── postgres_backup_info.yml
│   │   ├── postgres_backup_set_info.yml
│   │   ├── postgres_backup.yml
│   │   ├── postgres_extension_deactivate.yml
│   │   ├── postgres_extension_upgrade.yml
│   │   ├── postgres_info.yml
│   │   ├── postgres_logs_purge.yml
│   │   ├── postgres_major_upgrade.yml
│   │   ├── postgres_minor_update.yml
│   │   ├── postgres_restore_db_to_standby
│   │   ├── postgres_restore_end_of_backup
│   │   ├── postgres_restore_end_of_log
│   │   ├── postgres_restore_latest_PIT
│   │   ├── postgres_restore_LSN
│   │   ├── postgres_restore_PIT
│   │   ├── postgres_start_all.yml
│   │   ├── postgres_start.yml
│   │   ├── postgres_status_all.yml
│   │   ├── postgres_status.yml
│   │   ├── postgres_stop_all.yml
│   │   ├── postgres_stop.yml
│   │   └── postgres_vacuum_analyze.yml
│   ├── monitoring
│   │   ├── postgres_alerting.yml
│   │   ├── postgres_autovacuum_stats.yml
│   │   ├── postgres_connection_stats.yml
│   │   ├── postgres_disk_usage.yml
│   │   ├── postgres_health_check.yml
│   │   ├── postgres_memory_usage.yml
│   │   ├── postgres_query_performance.yml
│   │   └── postgres_replication_status.yml
│   ├── security_checks
│   │   ├── postgres_cis_benchmark_check.yml
│   │   ├── postgres_configuration_baseline_check.yml
│   │   ├── postgres_security_hardening_check.yml
│   │   └── postgres_user_privileges_check.yml
│   └── utilities
│       ├── precommit.yml
│       ├── site.yml
│       └── test.yml
├── roles
│   ├── check_postgres_env
│   │   └── tasks
│   │       └── main.yml
│   ├── check_variables
│   │   └── tasks
│   │       └── main.yml
│   ├── gather_instance_facts
│   │   └── tasks
│   │       └── main.yml
│   ├── print_instance_facts
│   │   └── tasks
│   │       └── main.yml
│   ├── print_instance_list
│   │   └── tasks
│   │       └── main.yml
│   └── print_instance_status
│       └── tasks
│           └── main.yml
├── secrets
│   ├── ansible.pub
│   ├── secret_vars.yml
│   └── vault
├── tasks
│   ├── install.yml
│   ├── instance_config_check.yml
│   ├── instance_configure.yml
│   ├── instance_create.yml
│   ├── instance_delete.yml
│   ├── instance_start_all.yml
│   ├── instance_stop_all.yml
│   └── uninstall.yml
├── templates
│   ├── pgbackrest.conf.j2
│   ├── pgbackrest_logrotate.j2
│   ├── pg_hba.conf.j2
│   ├── postgresql.conf.j2
│   ├── postgresql.service.j2
│   ├── postgres_sudoers.j2
│   └── README.md.j2
├── variables
│   ├── external.yml
│   └── main.yml
├── ansible.cfg
├── README.md
└── run_playbook.sh

```

---

## Usage

To execute a playbook at the command line, run:
```bash
run_playbook.sh

Ensure to specify required variables in file `variables\external.yml`.
```

For more details, refer to the specific playbooks inside each directory.

---

