#!/bin/bash
# -----------------------------------------------------------------------------
# File: pg_env.sh
# Project: PostgreSQL Automation Suite
# Maintainer: SSC Postgres Team
# Purpose: Set PostgreSQL environment variables for a specific instance.
#
# Features:
# - Validates the instance name and service file existence.
# - Dynamically determines PGDATA and PGPORT from the systemd service file.
# - Exports environment variables required for PostgreSQL operations.
# -----------------------------------------------------------------------------

# ------------------------------------------------------------
# Check if the argument is provided
# ------------------------------------------------------------
if [ -z "$1" ]; then
  echo -e "\n*** ERROR: Missising argument ***\n"
  echo -e "Usage: source $(basename "$0") <instance_name>\n"
  exit 1
fi

INSTANCE_NAME="$1"

# ------------------------------------------------------------
# Determine the service name
# ------------------------------------------------------------
SERVICE_NAME="postgresql-$INSTANCE_NAME"
SERVICE_FILE="/etc/systemd/system/$SERVICE_NAME.service"
if [ ! -f "$SERVICE_FILE" ]; then
  echo "Error: Service file $SERVICE_FILE not found."
  exit 1
fi

# ------------------------------------------------------------
# Extract PGDATA and PGPORT from the service file
# ------------------------------------------------------------
PGDATA=$(grep ExecStart "$SERVICE_FILE" | awk -F'-D ' '{print $2}' | awk '{print $1}')
PGPORT=$(grep ExecStart "$SERVICE_FILE" | awk -F'-p ' '{print $2}' | awk '{print $1}')

if [ -z "$PGDATA" ] || [ -z "$PGPORT" ]; then
  echo "Error: Could not determine PGDATA or PGPORT for instance $INSTANCE_NAME."
  exit 1
fi

# ------------------------------------------------------------
# Set the environment variables
# ------------------------------------------------------------
export PGDATA="$PGDATA"
export PGPORT="$PGPORT"
export PGUSER="postgres"

# ------------------------------------------------------------
# Print the environment variables to verify
# ------------------------------------------------------------
cat <<EOF

Environment variables set for instance: $INSTANCE_NAME

PGDATA=$PGDATA
PGPORT=$PGPORT
PGUSER=$PGUSER

Run the following command to ensure environment variables are set in your shell:

set | grep -E 'PGDATA|PGPORT|PGUSER'

If you don't see them, rerun this script with source (see Usage).

--------------------------------------------------------------
EOF

# ------------------------------------------------------------
# Display the service status
# ------------------------------------------------------------
echo "Service status for instance $INSTANCE_NAME:"
systemctl status "$SERVICE_NAME"

