INSERT INTO test_array_table (arr_col) VALUES (%s)
